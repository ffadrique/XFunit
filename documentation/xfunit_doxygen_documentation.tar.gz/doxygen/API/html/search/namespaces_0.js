var searchData=
[
  ['m_5fxfunit_5fassertion_363',['m_xfunit_assertion',['../namespacem__xfunit__assertion.html',1,'']]],
  ['m_5fxfunit_5fmanager_364',['m_xfunit_manager',['../namespacem__xfunit__manager.html',1,'']]],
  ['m_5fxfunit_5fsuite_365',['m_xfunit_suite',['../namespacem__xfunit__suite.html',1,'']]],
  ['m_5fxfunit_5funit_366',['m_xfunit_unit',['../namespacem__xfunit__unit.html',1,'']]]
];
