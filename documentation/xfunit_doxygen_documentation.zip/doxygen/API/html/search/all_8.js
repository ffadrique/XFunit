var searchData=
[
  ['is_5ferror_43',['is_error',['../structm__xfunit__manager_1_1t__xfunit__manager.html#a9ca91a49aa4ca58e21274aa8814bf305',1,'m_xfunit_manager::t_xfunit_manager::is_error()'],['../structm__xfunit__suite_1_1t__xfunit__suite.html#a9981e682fcf4384907715b596c6bf543',1,'m_xfunit_suite::t_xfunit_suite::is_error()'],['../structm__xfunit__unit_1_1t__xfunit__unit.html#a0ab35e0c10f5159a7913a5b92f030353',1,'m_xfunit_unit::t_xfunit_unit::is_error()']]],
  ['is_5fexecuted_44',['is_executed',['../structm__xfunit__unit_1_1t__xfunit__unit.html#a88bc6bee9f629c847c46550457922c68',1,'m_xfunit_unit::t_xfunit_unit']]],
  ['is_5fpassed_45',['is_passed',['../structm__xfunit__assertion_1_1t__xfunit__assertion.html#a52fb6ee752de3ebd1c6f5ee9d52108cd',1,'m_xfunit_assertion::t_xfunit_assertion::is_passed()'],['../structm__xfunit__unit_1_1t__xfunit__unit.html#ac127a5e18d1436f8061219fa277aa3c6',1,'m_xfunit_unit::t_xfunit_unit::is_passed()']]]
];
