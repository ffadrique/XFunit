var searchData=
[
  ['fail_5fonly_636',['fail_only',['../structm__xfunit__manager_1_1t__xfunit__manager.html#a220eaa479ebf594b6f3ebbaae3df4b3b',1,'m_xfunit_manager::t_xfunit_manager']]],
  ['failed_5fassertions_637',['failed_assertions',['../structm__xfunit__unit_1_1t__xfunit__unit.html#a477fa8c38715fa426b402791766d36c5',1,'m_xfunit_unit::t_xfunit_unit']]]
];
