var searchData=
[
  ['name_56',['name',['../structm__xfunit__assertion_1_1t__xfunit__assertion.html#aa0f31fe8b00d06c361f1346bf829a9a4',1,'m_xfunit_assertion::t_xfunit_assertion::name()'],['../structm__xfunit__suite_1_1t__xfunit__suite.html#a28e84f46db579636e36a4d4b4006f7d5',1,'m_xfunit_suite::t_xfunit_suite::name()'],['../structm__xfunit__unit_1_1t__xfunit__unit.html#a6a502a235ece6a58f0813c1754cfc06d',1,'m_xfunit_unit::t_xfunit_unit::name()']]]
];
