var searchData=
[
  ['handler_42',['handler',['../structm__xfunit__manager_1_1t__xfunit__manager.html#aa4685d93605a20de25396c1a42a701b6',1,'m_xfunit_manager::t_xfunit_manager']]]
];
